import React from 'react'
import Movies from './components/moviecomponent/Movies';
import './App.css'
import Image from './images/image.jpg'
import Header from './components/header/Header';
import Carusell from './components/carussel/Carusell';
import Add from './components/add/Add'


//intall Uid

const App = () => { 
  const movieArray = [
    {
      title: 'movie Title 1',
      image: 'https://thumbs.dfs.ivi.ru/storage4/contents/2/4/8f5207349fc15eafce601068b48b49.jpg/1216x370/',
      description: 'movie description',
      payment: false, 
      category: 'comedy',
      id: Date.now()
    },
    {
      title: 'movie Title 2',
      image: 'https://thumbs.dfs.ivi.ru/storage5/contents/f/2/f116a4ee4d32c0127e2e0d2e9c98b4.jpg/1216x370/',
      description: 'movie description',
      payment: true, 
  
    },
    {
      title: 'movie Title 3',
      image: 'https://thumbs.dfs.ivi.ru/storage31/contents/1/f/b4a58976d60f43e220d796a5241e93.jpg/1216x370/',
      description: 'movie description',
      payment: false, 
  
    },
    {
      title: 'movie Title 4',
      image: 'https://thumbs.dfs.ivi.ru/storage32/contents/e/0/253ee238948f6b46dc6505c662d5e0.jpg/1216x370/',
      description: 'movie description',
      payment: true, 
  
    },
    
  ]
  return (
    <div className="container">
      <Header/>
      <Carusell/>
      <Add/>
<h1>Recomended Movies For You!!</h1>
  <div className='movie-container'>
    { movieArray.map(item => {
      return (<Movies movie={item} />)
    }) }

 
    
  {/* <Movies/> */}
  </div>
  <h1>Comedy For You!!</h1>
  <div className='movie-container'>
    { movieArray.map(item => {
      return (<Movies movie={item} />)
    }) }

 
    
  {/* <Movies/> */}
  </div>
  
    </div>
  );
}



export default App;
