import * as React from 'react';
import { useTheme } from '@mui/material/styles';
import Box from '@mui/material/Box';
import MobileStepper from '@mui/material/MobileStepper';
import Paper from '@mui/material/Paper';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import Button from '@mui/material/Button';
import SwipeableViews from 'react-swipeable-views';
import './carusell.css'


const AutoPlaySwipeableViews = SwipeableViews;

const images = [
  {
 
    imgPath:
      'https://thumbs.dfs.ivi.ru/storage5/contents/f/2/f116a4ee4d32c0127e2e0d2e9c98b4.jpg/1216x370/',
  },
  {
   
    imgPath:
      'https://thumbs.dfs.ivi.ru/storage4/contents/2/4/8f5207349fc15eafce601068b48b49.jpg/1216x370/',
  },
  {
   
    imgPath:
      'https://thumbs.dfs.ivi.ru/storage31/contents/1/f/b4a58976d60f43e220d796a5241e93.jpg/1216x370/',
  },
  {
   
    imgPath:
      'https://thumbs.dfs.ivi.ru/storage32/contents/e/0/253ee238948f6b46dc6505c662d5e0.jpg/1216x370/',
  },
  {
    
    imgPath:
      'https://thumbs.dfs.ivi.ru/storage37/contents/0/7/d62ab3debbc554b69f9dcf975ebaeb.jpg/1216x370/',
  },
];

function SwipeableTextMobileStepper() {
  const theme = useTheme();
  const [activeStep, setActiveStep] = React.useState(0);
  const maxSteps = images.length;

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleStepChange = (step) => {
    setActiveStep(step);
  };

  return (
    <Box sx={{  size: 300 }}>
      <Paper
        square
        elevation={0}
        sx={{

          pl: 2,
          bgcolor: '#100e19',
          width:400,
        }}
      >
        
      </Paper>
      <AutoPlaySwipeableViews
        axis={theme.direction === 'rtl' ? 'x-reverse' : 'x'}
        index={activeStep}
        onChangeIndex={handleStepChange}
        enableMouseEvents
        sx={{
          display:'none',
        }}
      >
        {images.map((step, index) => (
          <div key={step.label}>
            {Math.abs(activeStep - index) <= 2 ? (
              <Box
                component="img"
                sx={{
                  display:'flex',
                  justifyContent:'center',
                  height: '370px',
                  alignitems:'center',
                  overflow: 'hidden',
                  width: '70%',
                  marginLeft:'15%',
                  borderRadius:'30px'
                }}
                src={step.imgPath}

              />
            ) : null}
          </div>
        ))}
      </AutoPlaySwipeableViews>
      <MobileStepper
      sx={{
        backgroundColor:'#100e19'
      }}
        steps={maxSteps}
        position="static"
        activeStep={activeStep}
        nextButton={
          <Button
            size="small"
            onClick={handleNext}
            disabled={activeStep === maxSteps - 1}
          >
            
            {theme.direction === 'rtl' ? (
              <ArrowBackIosNewIcon sx={{ fontSize: 40,color: 'rgba(255,255,255,.48)' }} className='arrows' />
            ) : (
              <ArrowForwardIosIcon  sx={{ 
                fontSize: 40,
                color: 'rgba(255,255,255,.48)'
               }} className='arrows'/>
            )}
          </Button>
        }
        backButton={
          <Button onClick={handleBack} disabled={activeStep === 0} sx={{
            size:40
        }}>
            {theme.direction === 'rtl' ? (
            
              <ArrowForwardIosIcon  sx={{ fontSize: 100,color: 'rgba(255,255,255,.48)' }} className='arrows'/>
            ) : (
              <ArrowBackIosNewIcon sx={{ fontSize: 40,color: 'rgba(255,255,255,.48)' }} className='arrows'/>
            )}
        
          </Button>
        }
      />
    </Box>
  );
}

export default SwipeableTextMobileStepper;
