import './movies.css'
import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { CardActionArea } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import Fab from '@mui/material/Fab';

const Movies = (props) => {
  console.log(props)
    return (
        <div className='movie-card'>
          
            <Fab color="secondary" aria-label="edit">
        <EditIcon />
      </Fab>
        <IconButton aria-label="delete" id='delete-btn'>
        <DeleteIcon />
      </IconButton>
        <Card sx={{ maxWidth: 205 }} sx={{
                borderRadius:'20px',
                border:'none'
              }}>
            <div className='movie-card'>
          <CardActionArea>
            <CardMedia
              component="img"
              height="270px"
              image={props.movie.image}
              alt="green iguana"
              sx={{width:'200px'}}
             
            />
            <CardContent sx={{}} className='cardcontent'>
              <Typography gutterBottom variant="h5" component="div" className='text' sx={{fontFamily:'',}}>
                {props.movie.title}
              </Typography>
              <Typography variant="body2" color="white" >
                {props.movie.description}
              </Typography>
            </CardContent>
          </CardActionArea>
          </div>
        </Card>
        </div>
      );
}

export default Movies

