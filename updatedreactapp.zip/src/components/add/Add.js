import React from 'react'
import './add.css'
import AddCircleIcon from '@mui/icons-material/AddCircle';

function add() {
    return (
        <div className='add-btn'>
            <AddCircleIcon
            sx={{
                fontSize:'100px',
                color:'lightgreen'
            }}
            />
        </div>
    )
}

export default add
