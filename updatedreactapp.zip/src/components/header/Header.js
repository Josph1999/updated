import './header.css'
import SearchIcon from '@mui/icons-material/Search';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';

const Header = () => {
    return (
       <div className="header">
           <div className='logo'>
           <img src="https://icons.tivision.ru/picture/ea003d,ffffff/iviLogoPlateRounded.svg" alt="IVI Logo" />
           </div>
           <div className='menu'>
               <ul>
                   <li>My ivi</li>
                   <li>What's new</li>
                   <li>Movies</li>
                   <li>Serials</li>
                   <li>Cartoons</li>
                   <li>TV channels</li>
                   <li>Collections</li>
               </ul>
           </div>
           <div className='searchbar'>
               <div className="searchbar-icon">
           <SearchIcon/>
           </div>
           <h3>Search</h3>
           </div>
           <div className='user'>
<PersonOutlineIcon sx={{ fontSize: 40 }} />
           </div>
       </div>

    )
}

Header.defaultProps ={
    title:'Title props'
}



export default Header

